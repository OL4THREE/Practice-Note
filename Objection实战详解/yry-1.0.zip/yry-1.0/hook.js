        // String[] v4 = {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9"};
        // String[] v5 = {"嘻", "❥", "÷", "∷", "●", "©", "额", "★", "※", "/"};
function Find_Code1(){
    Java.perform(function(){
        var javaString = Java.use('java.lang.String')
        for(var j=1;j<1000;j++){
            var j = javaString.$new(String(j));
            var v2_3 = Java.use("com.shimeng.颜如玉.颜如玉QQ2693533893").getSaltMD5(Java.use("com.shimeng.qq2693533893.MyServiceOne").颜如玉(j));
            // console.log("l, v2_3:",j,v2_3);
            if(v2_3 == '9DDEB743E935CE399F1DFAF080775366'){
                console.log("v2_3:",j);
            }
        }

            var i = javaString.$new(String(3744));
            var Code = Java.use("com.shimeng.颜如玉.颜如玉QQ2693533893").get(i);
            var v3 = Java.use("com.shimeng.qq2693533893.MyServiceOne").颜如玉(Java.use("com.shimeng.颜如玉.颜如玉QQ2693533893").getSaltMD5((javaString.$new(String(i^1288)))));
            var v3 = javaString.$new(v3).replaceAll("\\D+", "");
            var resu1 = "358" + javaString.$new(v3).substring(0, 9);
            console.log("i,Code,v3,resu1:",i,Code, v3, resu1);
    })
}
function Find_Code2(){
    Java.perform(function(){
        var javaString = Java.use('java.lang.String')
        for(var j=1;j<1000;j++){
            var j = javaString.$new(String(j));
            var v2_3 = Java.use("com.shimeng.颜如玉.颜如玉QQ2693533893").$new().getTwiceMD5ofString(Java.use("com.shimeng.颜如玉.颜如玉QQ2693533893").hex_sha1(j));
            //console.log("l, v2_3:",j,v2_3);
            if(v2_3 == '8D4FF507DCDA63C201EB8B99D4170900'){
                console.log("v2_3:",j);
            }
        }

        var i = javaString.$new(String(694));
        var Code = Java.use("com.shimeng.颜如玉.颜如玉QQ2693533893").get(i);
        var v3 = Java.use("com.shimeng.颜如玉.颜如玉QQ2693533893").hex_sha1(Java.use("com.shimeng.颜如玉.颜如玉QQ2693533893").$new().getTwiceMD5ofString(i));
        var v3 = javaString.$new(v3).replaceAll("\\D+", "");
        var resu2 = "694" + javaString.$new(v3).substring(0, 9);
        console.log("i,Code,v3,resu2",i,Code,v3,resu2)

        

    })
}
function Find_Code3(){
    Java.perform(function(){
        console.log("Inside java perform");
        var val = "123123";
        var string_class = Java.use("java.lang.String");
        var flag = Java.use("com.shimeng.颜如玉.颜如玉QQ2693533893").hex_sha1(string_class.$new(val));
        Java.choose("com.shimeng.qq2693533893.MyServiceOne",{
            onMatch:function(instance){
                instance.坐等前往世界的尽头的小船.value = flag;
            },onComplete:function(){console.log("flag,value",flag,val);}
        })
    });
}