function Find_Code(){
    Java.perform(function(){
        var javaString = Java.use('java.lang.String')
        for(var j=1;j<1000;j++){
            var j = javaString.$new(String(j));
            var v2_3 = Java.use("com.shimeng.颜如玉.颜如玉QQ2693533893").getSaltMD5(Java.use("com.shimeng.qq2693533893.MyServiceOne").颜如玉(j));
            // console.log("l, v2_3:",j,v2_3);
            if(v2_3 == '9DDEB743E935CE399F1DFAF080775366'){
                console.log("v2_3:",j);
            }
        }

            var i = javaString.$new(String(3744));
            var Code = Java.use("com.shimeng.颜如玉.颜如玉QQ2693533893").get(i);
            var v3 = Java.use("com.shimeng.qq2693533893.MyServiceOne").颜如玉(Java.use("com.shimeng.颜如玉.颜如玉QQ2693533893").getSaltMD5((javaString.$new(String(i^1288)))));
            var v3 = javaString.$new(v3).replaceAll("\\D+", "");
            var resu1 = "358" + javaString.$new(v3).substring(0, 9);
            console.log("i,Code,v3,resu1:",i,Code, v3, resu1);
    })
}