function Find_Code(){
    Java.perform(function(){
        var javaString = Java.use('java.lang.String')
        for(var j=1;j<1000;j++){
            var j = javaString.$new(String(j));
            var v2_3 = Java.use("com.shimeng.颜如玉.颜如玉QQ2693533893").$new().getTwiceMD5ofString(Java.use("com.shimeng.颜如玉.颜如玉QQ2693533893").hex_sha1(j));
            //console.log("l, v2_3:",j,v2_3);
            if(v2_3 == '8D4FF507DCDA63C201EB8B99D4170900'){
                console.log("v2_3:",j);
            }
        }

        var i = javaString.$new(String(694));
        var Code = Java.use("com.shimeng.颜如玉.颜如玉QQ2693533893").get(i);
        var v3 = Java.use("com.shimeng.颜如玉.颜如玉QQ2693533893").hex_sha1(Java.use("com.shimeng.颜如玉.颜如玉QQ2693533893").$new().getTwiceMD5ofString(i));
        var v3 = javaString.$new(v3).replaceAll("\\D+", "");
        var resu2 = "694" + javaString.$new(v3).substring(0, 9);
        console.log("i,Code,v3,resu2",i,Code,v3,resu2)

        

    })
}