function Find_Code(){
    Java.perform(function(){
        console.log("Inside java perform");
        var val = "123123";
        var string_class = Java.use("java.lang.String");
        var flag = Java.use("com.shimeng.颜如玉.颜如玉QQ2693533893").hex_sha1(string_class.$new(val));
        Java.choose("com.shimeng.qq2693533893.MyServiceOne",{
            onMatch:function(instance){
                instance.坐等前往世界的尽头的小船.value = flag;
            },onComplete:function(){console.log("flag,value",flag,val);}
        })
    });
}