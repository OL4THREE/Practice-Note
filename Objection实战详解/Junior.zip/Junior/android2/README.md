# 《Android Studio开发实战：从零基础到App上线(第2版)》附录源码
清华大学出版社出版　　　　作者：欧阳燊<br>
![](https://img30.360buyimg.com/vc/jfs/t1/29545/24/1403/204722/5c120c82Ec4c63e96/08fdf79267100fa1.jpg)
![](https://img30.360buyimg.com/vc/jfs/t1/28836/17/1432/614523/5c120c94Ed60a7fec/30902dd03f74e21c.jpg)
![](https://img30.360buyimg.com/vc/jfs/t1/19986/23/1414/821842/5c120ffeE19cce934/8c8328cfd08cc06e.jpg)
