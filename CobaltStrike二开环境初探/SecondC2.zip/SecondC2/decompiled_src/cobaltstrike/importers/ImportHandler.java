package importers;

public interface ImportHandler {
   void host(String var1, String var2, String var3, double var4);

   void service(String var1, String var2, String var3);
}
