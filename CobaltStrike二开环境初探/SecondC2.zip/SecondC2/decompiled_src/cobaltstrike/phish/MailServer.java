package phish;

public class MailServer {
   public String username = null;
   public String password = null;
   public int delay = 0;
   public boolean ssl = false;
   public String lhost = "";
   public int lport = 25;
   public boolean starttls = false;
}
