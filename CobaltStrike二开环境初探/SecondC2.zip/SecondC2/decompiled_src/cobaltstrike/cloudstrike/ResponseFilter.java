package cloudstrike;

public interface ResponseFilter {
   void filterResponse(Response var1);
}
