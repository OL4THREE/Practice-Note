package ui;

import java.awt.event.MouseEvent;

public interface DoubleClickListener {
   void doubleClicked(MouseEvent var1);
}
