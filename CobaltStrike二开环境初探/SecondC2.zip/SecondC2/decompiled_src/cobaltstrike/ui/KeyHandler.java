package ui;

public interface KeyHandler {
   void key_pressed(String var1);
}
