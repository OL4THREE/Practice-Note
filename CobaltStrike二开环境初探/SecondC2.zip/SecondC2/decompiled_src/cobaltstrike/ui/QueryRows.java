package ui;

import java.util.Map;

public interface QueryRows {
   Map[] getSelectedRows();
}
