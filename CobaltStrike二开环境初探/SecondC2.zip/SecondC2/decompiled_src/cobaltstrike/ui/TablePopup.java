package ui;

import java.awt.event.MouseEvent;

public interface TablePopup {
   void showPopup(MouseEvent var1);
}
