package ui;

public interface DataSelectionListener {
   void selected(Object var1);
}
