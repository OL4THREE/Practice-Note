package net.jsign.commons.cli;

public class ParseException extends Exception {
   private static final long serialVersionUID = 9112808380089253192L;

   public ParseException(String message) {
      super(message);
   }
}
