package net.jsign.bouncycastle.util;

public class Integers {
   public static int rotateLeft(int var0, int var1) {
      return Integer.rotateLeft(var0, var1);
   }

   public static int rotateRight(int var0, int var1) {
      return Integer.rotateRight(var0, var1);
   }

   public static Integer valueOf(int var0) {
      return var0;
   }
}
