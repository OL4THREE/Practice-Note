package net.jsign.bouncycastle.util.io;

import java.io.IOException;

public class StreamOverflowException extends IOException {
   public StreamOverflowException(String var1) {
      super(var1);
   }
}
