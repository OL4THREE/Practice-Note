package net.jsign.bouncycastle.operator;

public class OperatorCreationException extends OperatorException {
   public OperatorCreationException(String var1, Throwable var2) {
      super(var1, var2);
   }

   public OperatorCreationException(String var1) {
      super(var1);
   }
}
