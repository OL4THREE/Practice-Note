package net.jsign.bouncycastle.asn1;

public interface ASN1Choice {
}
