package net.jsign.bouncycastle.cms;

public class CMSVerifierCertificateNotValidException extends CMSException {
   public CMSVerifierCertificateNotValidException(String var1) {
      super(var1);
   }
}
