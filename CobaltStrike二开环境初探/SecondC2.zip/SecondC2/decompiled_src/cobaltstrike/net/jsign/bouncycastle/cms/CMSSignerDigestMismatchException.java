package net.jsign.bouncycastle.cms;

public class CMSSignerDigestMismatchException extends CMSException {
   public CMSSignerDigestMismatchException(String var1) {
      super(var1);
   }
}
