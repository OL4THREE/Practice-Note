package net.jsign.bouncycastle.operator;

public interface RawContentVerifier {
   boolean verify(byte[] var1, byte[] var2);
}
