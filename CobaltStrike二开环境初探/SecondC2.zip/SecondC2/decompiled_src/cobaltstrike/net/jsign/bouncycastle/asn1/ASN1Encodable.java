package net.jsign.bouncycastle.asn1;

public interface ASN1Encodable {
   ASN1Primitive toASN1Primitive();
}
