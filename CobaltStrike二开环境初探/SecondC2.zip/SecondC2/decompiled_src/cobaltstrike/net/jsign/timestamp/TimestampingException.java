package net.jsign.timestamp;

public class TimestampingException extends RuntimeException {
   public TimestampingException(String message, Throwable cause) {
      super(message, cause);
   }
}
