Please use qemu to load this file.
qemu-system-x86_64 -bios easybios
