#!/bin/bash
qemu-system-x86_64 \
-initrd rootfs.cpio \
-kernel bzImage \
-append "console=ttyS0 root=/dev/sda rw nokaslr quiet" \
-monitor /dev/null -m 128M -nographic \
-cpu kvm64,+smep
